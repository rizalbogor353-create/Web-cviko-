const links = [
  {
    title: "WhatsApp",
    subtitle: "Hubungi Cviko secara langsung",
    href: "https://wa.me/6281389309366",
    symbol: "✆",
  },
  {
    title: "Discord",
    subtitle: "Gabung ke komunitas Cviko",
    href: "https://discord.gg/jeqHPSCE",
    symbol: "◈",
  },
];

export default function Home() {
  return (
    <main className="page">
      <section className="card">
        <div className="logo" aria-label="Cviko">C</div>
        <h1>Web Cviko</h1>
        <p className="subtitle">
          Welcome! Pilih salah satu link di bawah ini untuk menghubungi atau bergabung.
        </p>
        <nav className="links" aria-label="Link Cviko">
          {links.map((link) => (
            <a
              className="link"
              href={link.href}
              key={link.title}
              target="_blank"
              rel="noopener noreferrer"
            >
              <span className="symbol" aria-hidden="true">{link.symbol}</span>
              <span>
                <strong>{link.title}</strong>
                <small>{link.subtitle}</small>
              </span>
              <span className="arrow" aria-hidden="true">↗</span>
            </a>
          ))}
        </nav>
      </section>
      <footer>© {new Date().getFullYear()} Cviko</footer>
    </main>
  );
}
