import { SiteHeader } from '@/components/site-header'
import { PackGrid } from '@/components/pack-grid'
import { OrderForm } from '@/components/order-form'
import { TermsList } from '@/components/terms-list'
import { SectionHeading } from '@/components/section-heading'
import { InfoGrid } from '@/components/info-grid'

export default function Page() {
  return (
    <div className="mx-auto max-w-4xl px-5 pb-12">
      <SiteHeader />
      <InfoGrid />
      <main className="mt-14 flex flex-col gap-14">
        <section aria-labelledby="packs-heading">
          <SectionHeading id="packs-heading" icon="/icons/chest.png">
            Kumpulan Texture &amp; Packs
          </SectionHeading>
          <PackGrid />
        </section>
        <section aria-labelledby="order-heading">
          <SectionHeading id="order-heading" icon="/icons/crafting.png">
            Order Commission Tools
          </SectionHeading>
          <OrderForm />
        </section>
        <section aria-labelledby="tos-heading">
          <SectionHeading id="tos-heading" icon="/icons/book.png">
            Terms of Service (TOS)
          </SectionHeading>
          <TermsList />
        </section>
      </main>
      <footer className="mt-16 text-center text-xs text-muted-foreground">
        <p>{'© 2026 Cviko Depth Of Cyan. All rights reserved.'}</p>
      </footer>
    </div>
  )
}
