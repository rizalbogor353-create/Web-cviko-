const terms = [
  'Pembayaran dilakukan di awal atau DP 50% sebelum pengerjaan dimulai.',
  'Proses pengerjaan estimasi 2 - 7 hari tergantung tingkat kesulitan model.',
  'Penggunaan karya secara komersial/dijual kembali harus mendapat izin eksplisit.',
  'Revisi maksimal 3 kali untuk perubahan minor.',
]

export function TermsList() {
  return (
    <ul className="flex list-disc flex-col gap-2 rounded-xl border border-border bg-card py-5 pr-5 pl-10 text-muted-foreground marker:text-primary">
      {terms.map((term) => (
        <li key={term}>{term}</li>
      ))}
    </ul>
  )
}
