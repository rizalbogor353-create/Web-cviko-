import Image from 'next/image'

export function SectionHeading({
  id,
  icon,
  children,
}: {
  id: string
  icon: string
  children: React.ReactNode
}) {
  return (
    <h2
      id={id}
      className="mb-5 flex items-center gap-3 border-b-2 border-primary pb-2 font-pixel text-2xl text-balance"
    >
      <Image
        src={icon}
        alt=""
        width={40}
        height={40}
        className="size-10 shrink-0 rounded-md border border-border [image-rendering:pixelated]"
      />
      {children}
    </h2>
  )
}
