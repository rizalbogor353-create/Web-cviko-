import { MessageCircle } from 'lucide-react'

const WHATSAPP_URL = 'https://wa.me/6281389309366'
const DISCORD_URL = 'https://discord.gg/jeqHPSCE'

function DiscordIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className="size-5 shrink-0 fill-current"
    >
      <path d="M19.73 5.33A19.8 19.8 0 0 0 14.86 3.8l-.6 1.22a18.3 18.3 0 0 0-4.52 0L9.14 3.8a19.7 19.7 0 0 0-4.88 1.53C1.18 9.9.34 14.37.76 18.78a19.9 19.9 0 0 0 5.98 3.03l1.29-2.1a12.9 12.9 0 0 1-2.03-.97l.5-.39c3.91 1.81 8.15 1.81 12.02 0l.51.39c-.65.38-1.33.7-2.04.97l1.29 2.1a19.8 19.8 0 0 0 5.99-3.03c.5-5.1-.86-9.53-4.54-13.45ZM8.73 15.99c-1.17 0-2.13-1.07-2.13-2.39s.94-2.39 2.13-2.39 2.15 1.08 2.13 2.39c0 1.32-.94 2.39-2.13 2.39Zm6.54 0c-1.17 0-2.13-1.07-2.13-2.39s.94-2.39 2.13-2.39 2.15 1.08 2.13 2.39c0 1.32-.93 2.39-2.13 2.39Z" />
    </svg>
  )
}

export function OrderForm() {
  return (
    <div className="flex flex-col gap-4 rounded-xl border border-border bg-card p-5">
      <p className="text-sm leading-relaxed text-muted-foreground">
        Mau pesan custom tools atau punya ide sendiri? Pilih salah satu tombol di bawah untuk menghubungi Cviko.
      </p>

      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-[#25D366] px-4 py-3 font-bold text-white transition-colors hover:bg-[#1ebe5d] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#25D366]"
      >
        <MessageCircle className="size-5 shrink-0" aria-hidden="true" />
        Order via WhatsApp
      </a>
      <a
        href={DISCORD_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-[#5865F2] px-4 py-3 font-bold text-white transition-colors hover:bg-[#4752c4] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#5865F2]"
      >
        <DiscordIcon />
        Order via Discord
      </a>
    </div>
  )
}
