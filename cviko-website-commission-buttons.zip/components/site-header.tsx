'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Menu, X, Zap } from 'lucide-react'

const navLinks = [
  { href: '#packs-heading', label: 'Packs' },
  { href: '#order-heading', label: 'Commission' },
  { href: '#tos-heading', label: 'TOS' },
]

export function TopBar() {
  const [open, setOpen] = useState(false)

  return (
    <nav aria-label="Navigasi utama" className="relative border-b border-border/60 py-4">
      <div className="flex items-center gap-3">
        <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl border border-border bg-card">
          <span
              role="img"
              aria-label="Logo Cviko Art Tools"
  className="size-8 bg-primary"
  style={{
  maskImage: 'url(/images/logo.png)',
  WebkitMaskImage: 'url(/images/logo.png)',
  maskSize: '140%',
  WebkitMaskSize: '140%',
                maskPosition: 'center',
                WebkitMaskPosition: 'center',
                maskRepeat: 'no-repeat',
                WebkitMaskRepeat: 'no-repeat',
              }}
            />
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-pixel text-lg leading-tight text-foreground">Menu Informasi</p>
          <p className="truncate text-xs text-muted-foreground">
            {navLinks.map((link, i) => (
              <span key={link.href}>
                {i > 0 && <span aria-hidden="true">{' · '}</span>}
                <a href={link.href} className="hover:text-primary">
                  {link.label}
                </a>
              </span>
            ))}
          </p>
        </div>
        <a
          href="#order-heading"
          aria-label="Langsung ke form commission"
          className="relative flex size-12 shrink-0 items-center justify-center rounded-2xl border border-border bg-card hover:border-primary"
        >
          <Zap className="size-5 text-primary" aria-hidden="true" />
          <span className="absolute right-2 top-2 size-1.5 rounded-full bg-online" aria-hidden="true" />
        </a>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? 'Tutup menu' : 'Buka menu'}
          className="flex size-12 shrink-0 items-center justify-center rounded-2xl border border-border bg-card hover:border-primary"
        >
          {open ? <X className="size-5" aria-hidden="true" /> : <Menu className="size-5" aria-hidden="true" />}
        </button>
      </div>
      {open && (
        <ul
          id="mobile-menu"
          className="absolute right-0 top-full z-20 mt-2 flex w-48 flex-col gap-1 rounded-2xl border border-border bg-card p-2 shadow-xl"
        >
          {navLinks.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                onClick={() => setOpen(false)}
                className="block rounded-xl px-3 py-2 font-pixel text-sm hover:bg-secondary"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>
      )}
    </nav>
  )
}

export function HeroCard() {
  return (
    <header className="relative mt-5 overflow-hidden rounded-[2rem] border border-border/80 shadow-[0_0_40px_-10px_var(--primary)]">
      <Image
        src="/images/hero-banner.png"
        alt=""
        fill
        priority
        sizes="(min-width: 896px) 896px, 100vw"
        className="object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-background/10" aria-hidden="true" />

      <div className="relative flex min-h-72 flex-col justify-between gap-10 p-5 sm:min-h-96 sm:p-8">
        <div className="flex items-center justify-between gap-3">
          <span className="inline-flex items-center gap-2 rounded-full bg-background/50 py-1 pl-1 pr-3 backdrop-blur">
            <span className="flex size-6 items-center justify-center rounded-full bg-online/20">
              <span className="size-2.5 rounded-full bg-online" aria-hidden="true" />
            </span>
            <span className="font-pixel text-xs tracking-[0.2em] text-foreground sm:text-sm">COMMISSION OPEN</span>
          </span>
          <span className="hidden font-pixel text-xs tracking-[0.2em] text-foreground/70 sm:inline sm:text-sm">
            {'CVIKO STUDIO · 3D'}
          </span>
        </div>

        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-4">
            <Image
              src="/images/profile.png"
              alt="Foto profil Cviko"
              width={96}
              height={96}
              className="size-16 shrink-0 rounded-2xl border-2 border-primary object-cover sm:size-20"
            />
            <h1 className="font-pixel text-5xl leading-none text-foreground drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)] sm:text-7xl">
              Cviko
            </h1>
          </div>
          <p className="font-pixel text-xs tracking-[0.12em] text-accent text-pretty sm:text-sm sm:tracking-[0.25em]">
            {'3D Skin Artist · Commission · Content Creator'}
          </p>
        </div>
      </div>
    </header>
  )
}

export function SiteHeader() {
  return (
    <>
      <TopBar />
      <HeroCard />
    </>
  )
}
