import { ExternalLink } from 'lucide-react'

const packs = [
  {
    title: 'Custom 3D Tools Pack',
    description: 'Model 3D kustom untuk Netherite Tools & Sword.',
    image: '/placeholder.svg?height=360&width=600',
    href: '#',
    linkLabel: 'Download / Modrinth',
  },
  {
    title: '3D Trident & Attachables',
    description: 'Resource pack khusus custom model trident & entity.',
    image: '/placeholder.svg?height=360&width=600',
    href: '#',
    linkLabel: 'Download / CurseForge',
  },
]

export function PackGrid() {
  return (
    <ul className="grid grid-cols-1 gap-5 sm:grid-cols-2">
      {packs.map((pack) => (
        <li
          key={pack.title}
          className="flex flex-col rounded-xl border border-border bg-card p-4 text-center"
        >
          <img
            src={pack.image || '/placeholder.svg'}
            alt={`Preview ${pack.title}`}
            className="mb-3 h-44 w-full rounded-lg object-cover"
          />
          <h3 className="mb-1 text-lg font-semibold">{pack.title}</h3>
          <p className="mb-4 flex-1 text-sm text-muted-foreground">{pack.description}</p>
          <a
            href={pack.href}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 self-center rounded-md bg-primary px-4 py-2 text-sm font-bold text-primary-foreground transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-2 focus-visible:outline-offset-2"
          >
            {pack.linkLabel}
            <ExternalLink className="size-4" aria-hidden="true" />
          </a>
        </li>
      ))}
    </ul>
  )
}
