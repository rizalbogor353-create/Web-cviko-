import type { ComponentType, SVGProps } from 'react'
import { Clock, Globe, Layers, Signal } from 'lucide-react'

type IconComponent = ComponentType<SVGProps<SVGSVGElement>>
type InfoItem = { icon: IconComponent; label: string; value: string; highlight?: boolean }

function RoundedCube(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M10.6 2.6a3 3 0 0 1 2.8 0l6.5 3.5A2.2 2.2 0 0 1 21 8v8a2.2 2.2 0 0 1-1.1 1.9l-6.5 3.5a3 3 0 0 1-2.8 0l-6.5-3.5A2.2 2.2 0 0 1 3 16V8a2.2 2.2 0 0 1 1.1-1.9z" />
      <path d="M3.6 7 12 11.5 20.4 7" />
      <path d="M12 11.5V21.6" />
    </svg>
  )
}

const items: InfoItem[] = [
  { icon: RoundedCube, label: 'Spesialis', value: '3D Skin Art', highlight: true },
  { icon: Globe, label: 'Negara', value: 'Indonesia' },
  { icon: Layers, label: 'Platform', value: 'Java & Bedrock' },
  { icon: Clock, label: 'Pengerjaan', value: '2 - 7 Hari' },
  { icon: Signal, label: 'Status', value: 'Online' },
]

const slotsUsed = 3
const slotsTotal = 5

export function InfoGrid() {
  const percent = Math.round((slotsUsed / slotsTotal) * 100)

  return (
    <section aria-label="Info Cviko" className="mt-4 rounded-3xl border border-border/80 bg-card/60 p-2">
      <ul className="grid grid-cols-2 gap-1.5">
        {items.map(({ icon: Icon, label, value, highlight }) => (
          <li
            key={label}
            className="flex min-w-0 items-center gap-2 rounded-xl border border-border/70 bg-background/60 px-2.5 py-2"
          >
            {highlight ? (
              <span className="flex size-7 shrink-0 items-center justify-center rounded-lg border border-border bg-card">
                <Icon className="size-3.5 text-primary" aria-hidden="true" />
              </span>
            ) : (
              <Icon className="size-5 shrink-0 text-primary" aria-hidden="true" />
            )}
            <div className="min-w-0">
              <p className={`truncate font-pixel text-[10px] uppercase leading-tight tracking-wider ${highlight ? 'text-accent' : 'text-muted-foreground'}`}>
                {label}
              </p>
              <p className="flex items-center gap-1.5 truncate text-xs font-semibold leading-tight text-foreground">
                {label === 'Status' && <span className="size-1.5 shrink-0 rounded-full bg-online" aria-hidden="true" />}
                {value}
              </p>
            </div>
          </li>
        ))}
        <li className="flex min-w-0 flex-col justify-center gap-1.5 rounded-xl border border-border/70 bg-background/60 px-2.5 py-2">
          <div className="flex items-center justify-between">
            <span className="font-pixel text-[10px] uppercase tracking-wider text-muted-foreground">Slot</span>
            <span className="font-pixel text-[10px] text-accent">{`${slotsUsed}/${slotsTotal}`}</span>
          </div>
          <div
            role="progressbar"
            aria-label="Slot commission terisi"
            aria-valuenow={slotsUsed}
            aria-valuemin={0}
            aria-valuemax={slotsTotal}
            className="h-1.5 overflow-hidden rounded-full bg-secondary"
          >
            <div className="h-full rounded-full bg-gradient-to-r from-primary to-accent" style={{ width: `${percent}%` }} />
          </div>
        </li>
      </ul>
    </section>
  )
}
